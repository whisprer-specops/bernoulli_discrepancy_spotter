
#include "laplace_estimator.h"
#include <stdlib.h>
#include <math.h>

int compare(const void* a, const void* b) {
    double diff = (*(double*)a - *(double*)b);
    return (diff > 0) - (diff < 0);
}

double median(double* data, size_t n) {
    qsort(data, n, sizeof(double), compare);
    if (n % 2 == 0)
        return (data[n / 2 - 1] + data[n / 2]) / 2;
    else
        return data[n / 2];
}

void estimate_laplace_params(const double* data, size_t n, double* location, double* scale) {
    double* temp = malloc(n * sizeof(double));
    for (size_t i = 0; i < n; i++) temp[i] = data[i];

    double loc = median(temp, n);
    *location = loc;

    for (size_t i = 0; i < n; i++) temp[i] = fabs(data[i] - loc);
    *scale = median(temp, n) / log(2.0);  // Scale estimation using MAD (Median Absolute Deviation)

    free(temp);
}
