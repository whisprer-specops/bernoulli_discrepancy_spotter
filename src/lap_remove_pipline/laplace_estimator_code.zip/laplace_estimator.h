
#ifndef _LAPLACE_ESTIMATOR_H_
#define _LAPLACE_ESTIMATOR_H_

#include <stddef.h>

void estimate_laplace_params(const double* data, size_t n, double* location, double* scale);

#endif
